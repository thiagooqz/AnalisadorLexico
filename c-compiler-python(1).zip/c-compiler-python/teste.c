#include <stdio.h>

int main() {
    int n1 = 42; 
    /*
    printf("Número: ", n1);
    */
    return 0;
} 
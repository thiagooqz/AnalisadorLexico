#!/usr/bin/env python3

import sys
import re

class Token:
    # Classe que representa um token do código fonte
    def __init__(self, type, value, line=0, column=0):
        # Inicializa um token com seu tipo, valor e posição no código
        self.type = type    # Tipo do token
        self.value = value  # Valor do token
        self.line = line    # Linha onde o token foi encontrado
        self.column = column  # Coluna onde o token foi encontrado
    
    def __str__(self):
        # Retorna uma representação em string do token
        return f"{self.type}({self.value})"

class Lexer:
    def __init__(self, text):
        # Inicializa o lexer
        self.text = text          # Texto fonte completo
        self.pos = 0              # Posição atual no texto
        self.current_char = self.text[0] if text else None  # Caractere atual
        self.line = 1             # Linha atual
        self.column = 1           # Coluna atual
    
    def error(self):
        # Lança uma exceção quando encontra um caractere inválido
        raise Exception(f"Caractere inválido: '{self.current_char}' na linha {self.line}, coluna {self.column}")
    
    def advance(self):
        # Avança para o próximo caractere no texto
        if self.current_char == '\n':
            # Se encontrar uma quebra de linha, incrementa a linha e reseta a coluna
            self.line += 1
            self.column = 0
        
        self.pos += 1             # Avança a posição
        self.column += 1          # Incrementa a coluna
        
        if self.pos >= len(self.text):
            # Se chegou ao fim do texto, define current_char como None
            self.current_char = None
        else:
            # Caso contrário, pega o próximo caractere
            self.current_char = self.text[self.pos]
    
    def peek(self):
        # Olha o próximo caractere sem avançar a posição
        peek_pos = self.pos + 1
        if peek_pos >= len(self.text):
            return None
        return self.text[peek_pos]
    
    def skip_whitespace(self):
        # Pula espaços em branco, tabulações e quebras de linha
        while self.current_char and self.current_char.isspace():
            self.advance()
    
    def skip_comment(self):
        # Processa comentários do código
        # Comentários de uma linha //
        if self.current_char == '/' and self.peek() == '/':
            self.advance()  # Pula a primeira barra
            self.advance()  # Pula a segunda barra
            while self.current_char and self.current_char != '\n':
                # Pula todos os caracteres até encontrar uma quebra de linha
                self.advance()
            if self.current_char == '\n':
                self.advance()  # Pula a quebra de linha
        # Comentários multilinha /* ... */
        elif self.current_char == '/' and self.peek() == '*':
            self.advance()  # Pula a primeira barra
            self.advance()  # Pula o asterisco
            while self.current_char:
                # Procura pelo fechamento do comentário */
                if self.current_char == '*' and self.peek() == '/':
                    self.advance()  # Pula o asterisco
                    self.advance()  # Pula a barra
                    break
                self.advance()  # Pula o caractere atual
    
    def number(self):
        # Processa números (inteiros e decimais)
        result = ''        # String para armazenar o número
        col = self.column  # Guarda a coluna inicial
        
        # Coleta dígitos inteiros
        while self.current_char and self.current_char.isdigit():
            result += self.current_char
            self.advance()
        
        # Verifica se é um número decimal
        if self.current_char == '.':
            result += '.'
            self.advance()
            
            # Coleta dígitos decimais
            while self.current_char and self.current_char.isdigit():
                result += self.current_char
                self.advance()
            
            return Token('NUMBER', result, self.line, col)
        
        return Token('NUMBER', result, self.line, col)
    
    def string(self):
        # Processa strings (texto entre aspas duplas)
        result = ''        # String para armazenar o conteúdo
        col = self.column  # Guarda a coluna inicial
        
        self.advance()  # Pula a primeira aspas
        
        while self.current_char and self.current_char != '"':
            # Processa caracteres de escape
            if self.current_char == '\\':
                self.advance()  # Pula a barra invertida
                if self.current_char == 'n':
                    result += '\n'  # Nova linha
                elif self.current_char == 't':
                    result += '\t'  # Tabulação
                elif self.current_char == '"':
                    result += '"'   # Aspas
                else:
                    result += self.current_char  # Outro caractere de escape
            else:
                result += self.current_char  # Caractere normal
            self.advance()
        
        if self.current_char == '"':
            self.advance()  # Pula a aspas final
        else:
            raise Exception(f"String não fechada na linha {self.line}")
        
        return Token('STRING', result, self.line, col)
    
    def id(self):
        # Processa identificadores e palavras-chave
        result = ''        # String para armazenar o identificador
        col = self.column  # Guarda a coluna inicial
        
        # Coleta letras, dígitos e underscores
        while self.current_char and (self.current_char.isalnum() or self.current_char == '_'):
            result += self.current_char
            self.advance()
        
        # Dicionário de palavras-chave
        keywords = {
            'int': 'KEYWORD',
            'float': 'KEYWORD',
            'char': 'KEYWORD',
            'return': 'KEYWORD',
            'if': 'KEYWORD',
            'else': 'KEYWORD',
            'while': 'KEYWORD',
            'for': 'KEYWORD',
            'void': 'KEYWORD',
            'include': 'KEYWORD'
        }
        
        # Verifica se é uma palavra-chave ou identificador
        token_type = keywords.get(result, 'ID')
        return Token(token_type, result, self.line, col)
    
    def char(self):
        # Processa caracteres (entre aspas simples)
        col = self.column  # Guarda a coluna inicial
        
        self.advance()  # Pula a primeira aspas
        
        # Processa caracteres de escape
        if self.current_char == '\\':
            self.advance()  # Pula a barra invertida
            if self.current_char == 'n':
                char_value = '\n'  # Nova linha
            elif self.current_char == 't':
                char_value = '\t'  # Tabulação
            elif self.current_char == '0':
                char_value = '\0'  # Nulo
            else:
                char_value = self.current_char  # Outro caractere de escape
            self.advance()
        elif self.current_char is None:
            self.error("Caractere não fechado")
        else:
            char_value = self.current_char  # Caractere normal
            self.advance()
        
        if self.current_char != "'":
            self.error("Caractere não fechado corretamente")
        self.advance()  # Pula a aspas final
        
        return Token('CHAR', char_value, self.line, col)
    
    def get_next_token(self):
        # Método principal que retorna o próximo token
        while self.current_char:
            # Pula espaços em branco
            if self.current_char.isspace():
                self.skip_whitespace()
                continue
            
            # Pula comentários
            if self.current_char == '/' and (self.peek() == '/' or self.peek() == '*'):
                self.skip_comment()
                continue
            
            # Processa números
            if self.current_char.isdigit():
                return self.number()
            
            # Processa identificadores
            if self.current_char.isalpha() or self.current_char == '_':
                return self.id()
            
            # Processa caracteres
            if self.current_char == "'":
                return self.char()
            
            # Processa strings
            if self.current_char == '"':
                return self.string()
            
            # Processa diretivas do pré-processador
            if self.current_char == '#':
                col = self.column
                self.advance() 
                return Token('PREPROCESSOR', '#', self.line, col)
            
            # Processa operadores e símbolos
            if self.current_char in '+-*/=<>!&|%^~?:;,.()[]{}':
               
                # Operadores de dois caracteres
                two_char_ops = {
                    '==': 'OPERATOR',
                    '!=': 'OPERATOR',
                    '<=': 'OPERATOR',
                    '>=': 'OPERATOR',
                    '+=': 'OPERATOR',
                    '-=': 'OPERATOR',
                    '*=': 'OPERATOR',
                    '/=': 'OPERATOR',
                    '++': 'OPERATOR',
                    '--': 'OPERATOR',
                    '&&': 'OPERATOR',
                    '||': 'OPERATOR'
                }
                
                # Verifica se é um operador de dois caracteres
                if self.current_char + (self.peek() or '') in two_char_ops:
                    op = self.current_char + self.peek()
                    col = self.column
                    self.advance()
                    self.advance()
                    return Token('OPERATOR', op, self.line, col)
                
                # Categorias de símbolos
                symbol_categories = {
                    '(': 'LPAREN',
                    ')': 'RPAREN',
                    '{': 'LBRACE',
                    '}': 'RBRACE',
                    '[': 'LBRACKET',
                    ']': 'RBRACKET',
                    ';': 'SEMICOLON',
                    ',': 'COMMA'
                }
                
                # Processa símbolos de um caractere
                symbol = self.current_char
                col = self.column
                self.advance()
                
                token_type = symbol_categories.get(symbol, 'OPERATOR')
                return Token(token_type, symbol, self.line, col)
            
            self.error()
        
        return Token('EOF', None, self.line, self.column)

def main():
    # Função principal do programa
    if len(sys.argv) != 2:
        # Verifica se foi fornecido um arquivo de entrada
        print("Uso: python simple_c_compiler.py arquivo.c")
        return 1
    
    input_file = sys.argv[1]
    
    try:
        # Lê o arquivo de entrada
        with open(input_file, 'r') as f:
            text = f.read()
        
        # Cria o lexer e processa os tokens
        lexer = Lexer(text)
        token = lexer.get_next_token()
        
        # Imprime os tokens encontrados
        print("Lista de tokens:")
        while token.type != 'EOF':
            print(f"Linha {token.line}, Coluna {token.column}: {token}")
            token = lexer.get_next_token()
        
        return 0
    except Exception as e:
        # Trata erros durante a execução
        print(f"Erro: {e}")
        return 1

if __name__ == "__main__":
    # Ponto de entrada do programa
    sys.exit(main()) 